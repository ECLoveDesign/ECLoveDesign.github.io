# Stacked Bar Chart with percentage data with Chart.JS

A Pen created on CodePen.io. Original URL: [https://codepen.io/sakilimran/pen/NoLpBq](https://codepen.io/sakilimran/pen/NoLpBq).

