/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'templates', 'af', {
	button: 'Sjablone',
	emptyListMsg: '(Geen sjablone gedefineer nie)',
	insertOption: 'Vervang huidige inhoud',
	options: 'Sjabloon opsies',
	selectPromptMsg: 'Kies die sjabloon om te gebruik in die redigeerder (huidige inhoud gaan verlore):',
	title: 'Inhoud Sjablone'
} );
