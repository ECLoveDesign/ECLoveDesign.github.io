/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'templates', 'et', {
	button: 'Mall',
	emptyListMsg: '(Ühtegi malli ei ole defineeritud)',
	insertOption: 'Praegune sisu asendatakse',
	options: 'Malli valikud',
	selectPromptMsg: 'Palun vali mall, mis avada redaktoris<br />(praegune sisu läheb kaotsi):',
	title: 'Sisumallid'
} );
