/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'templates', 'sr-latn', {
	button: 'Obrasci',
	emptyListMsg: '(Nema definisanih obrazaca)',
	insertOption: 'Zameni trenutni sadržaj.',
	options: 'Opcije šablona.',
	selectPromptMsg: 'Molimo Vas da odaberete obrazac koji će se otvoriti u uredjivaču<br />(trenutni sadržaj će se izgubiti):',
	title: 'Dostupni obrasci'
} );
