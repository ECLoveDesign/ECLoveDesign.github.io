/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'templates', 'sr', {
	button: 'Обрасци',
	emptyListMsg: '(Нема дефинисаних образаца)',
	insertOption: 'Замени тренутни садржај',
	options: 'Опције шаблона',
	selectPromptMsg: 'Молим вас да одаберете образац који ће се отворити у уређивачу<br />(тренутни саржај ће се изгубити):',
	title: 'Доступни обрасци'
} );
