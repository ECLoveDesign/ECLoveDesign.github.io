/*
Copyright (c) 2003-2022, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'templates', 'lv', {
	button: 'Sagataves',
	emptyListMsg: '(Nav norādītas sagataves)',
	insertOption: 'Aizvietot pašreizējo saturu',
	options: 'Sagataves uzstādījumi',
	selectPromptMsg: 'Lūdzu, norādiet sagatavi, ko atvērt editorā<br>(patreizējie dati tiks zaudēti):',
	title: 'Satura sagataves'
} );
